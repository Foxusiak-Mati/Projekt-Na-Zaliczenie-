﻿using NAudio.Wave;
using System;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Gra_Okienkowa
{
    public partial class Form1 : Form
    {
        private string player1Symbol = "X";
        private string player2Symbol = "O";
        private WaveOutEvent waveOut;
        private AudioFileReader audioFile;
        private bool isAgainstComputer = false;
        private string computerSymbol = "O";
        private DifficultyLevel difficultyLevel = DifficultyLevel.Easy;  // Domyślnie łatwy poziom trudności
        private bool gameStarted = false;
        private int player1Wins = 0;
        private int player2Wins = 0;
        private int draws = 0;
        private int boardSize = 3;  // Domyślny rozmiar planszy
        private Button[,] buttons;  // Tablica przycisków planszy
        private GameState currentGameState;
        private Random random = new Random();
        private Stack<int> moveHistory;


        public Form1()
        {
            InitializeComponent();
            waveOut = new WaveOutEvent();
            audioFile = new AudioFileReader("H:/Projekt C#/Song1.mp3"); // <--- Możliwa zmiana lokalizacji pliku <---
            waveOut.Init(audioFile);
            waveOut.Play();
            InitializeBoard();
            moveHistory = new Stack<int>();
        }

        String[] gameBoard = new string[9];
        int currentTurn = 0;

        public string returnSymbol(int turn)
        {
            return (turn % 2 == 0) ? player2Symbol : player1Symbol;
        }

        public System.Drawing.Color determineColor(String symbol)
        {
            if (symbol.Equals("O"))
            {
                return System.Drawing.Color.Lime;
            }
            else if (symbol.Equals("X"))
            {
                return System.Drawing.Color.RoyalBlue;
            }
            return System.Drawing.Color.White;
        }

        private bool CheckCombination(string combination, string symbol)
        {
            return combination.All(c => c.ToString() == symbol);
        }

        public void checkForWinner()
        {
            for (int i = 0; i < 8; i++)
            {
                String currentCombination = "";
                int one = 0, two = 0, three = 0;

                switch (i)
                {
                    case 0:
                        if (gameBoard.Length > 8)
                        {
                            combination = gameBoard[0] + gameBoard[4] + gameBoard[8];
                            one = 0;
                            two = 4;
                            three = 8;
                        }
                        break;
                    case 1:
                        if (gameBoard.Length > 6)
                        {
                            combination = gameBoard[2] + gameBoard[4] + gameBoard[6];
                            one = 2;
                            two = 4;
                            three = 6;
                        }
                        break;
                    case 2:
                        if (gameBoard.Length > 2)
                        {
                            combination = gameBoard[0] + gameBoard[1] + gameBoard[2];
                            one = 0;
                            two = 1;
                            three = 2;
                        }
                        break;
                    case 3:
                        if (gameBoard.Length > 5)
                        {
                            combination = gameBoard[3] + gameBoard[4] + gameBoard[5];
                            one = 3;
                            two = 4;
                            three = 5;
                        }
                        break;
                    case 4:
                        if (gameBoard.Length > 8)
                        {
                            combination = gameBoard[6] + gameBoard[7] + gameBoard[8];
                            one = 6;
                            two = 7;
                            three = 8;
                        }
                        break;
                    case 5:
                        if (gameBoard.Length > 6)
                        {
                            combination = gameBoard[0] + gameBoard[3] + gameBoard[6];
                            one = 0;
                            two = 3;
                            three = 6;
                        }
                        break;
                    case 6:
                        if (gameBoard.Length > 7)
                        {
                            combination = gameBoard[1] + gameBoard[4] + gameBoard[7];
                            one = 1;
                            two = 4;
                            three = 7;
                        }
                        break;
                    case 7:
                        if (gameBoard.Length > 8)
                        {
                            combination = gameBoard[2] + gameBoard[5] + gameBoard[8];
                            one = 2;
                            two = 5;
                            three = 8;
                        }
                        break;
                }

                if (one < gameBoard.Length && two < gameBoard.Length && three < gameBoard.Length)
                {
                    combination = gameBoard[one] + gameBoard[two] + gameBoard[three];
                    if (CheckCombination(combination, "O"))
                    {
                        SetWinner(one, two, three, GameState.Player2Won);
                        return;
                    }
                    else if (CheckCombination(combination, "X"))
                    {
                        SetWinner(one, two, three, GameState.Player1Won);
                        return;
                    }
                }

                private bool CheckCombination(string combination, string symbol)
                {
                    return combination.All(c => c.ToString() == symbol);
                }

                if (combination.Equals("OOO"))
                {
                    SetButtonColor(one, System.Drawing.Color.Red);
                    SetButtonColor(two, System.Drawing.Color.Red);
                    SetButtonColor(three, System.Drawing.Color.Red);
                    currentGameState = GameState.Player2Won;
                    SetVisualEffects(currentGameState);
                    player2Wins++;
                    ShowGameStats();
                }
                else if (combination.Equals("XXX"))
                {
                    SetButtonColor(one, System.Drawing.Color.Red);
                    SetButtonColor(two, System.Drawing.Color.Red);
                    SetButtonColor(three, System.Drawing.Color.Red);
                    currentGameState = GameState.Player1Won;
                    SetVisualEffects(currentGameState);
                    player1Wins++;
                    ShowGameStats();
                }
                CheckDraw();
            }
        }

        private void ResetGame()
        {
            for (int i = 0; i < boardSize; i++)
            {
                for (int j = 0; j < boardSize; j++)
                {
                    buttons[i, j].Text = "";
                    buttons[i, j].BackColor = Color.White;
                }
            }

            Array.Clear(gameBoard, 0, gameBoard.Length);
            currentTurn = 0;

            player1Symbol = "X";
            player2Symbol = "O";

            gameStarted = false; // Poprawienie tego warunku

            button10.Enabled = true;
            currentGameState = GameState.NotStarted;
        }

        public void ResetButtonClick(object sender, EventArgs e)
        {
            ResetGame();
        }

        public void SetButtonColor(int number, Color color)
        {
            if (number >= 0 && number < boardSize * boardSize)
            {
                buttons[number / boardSize, number % boardSize].BackColor = color;
            }
        }

        public void CheckDraw()
        {
            int counter = 0;
            for (int i = 0; i < gameBoard.Length; i++)
            {
                if (gameBoard[i] != null) { counter++; }

                if (counter == 9)
                {
                    ResetGame();
                    MessageBox.Show(" REMIS! ", " Dziś nie ma zwycięzcy", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            player1Symbol = GetUserInput("Gracz 1, wprowadź swój symbol:", "Personalizacja znaku gracza 1");
        }


        private void button12_Click(object sender, EventArgs e)
        {
            player2Symbol = GetUserInput("Gracz 2, wprowadź swój symbol:", "Personalizacja znaku gracza 2");
        }
        private string GetUserInput(string prompt, string title)
        {
            Form promptForm = new Form();
            promptForm.Width = 300;
            promptForm.Height = 150;
            promptForm.Text = title;

            Label textLabel = new Label() { Left = 50, Top = 20, Text = prompt };
            TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 200 };
            Button confirmation = new Button() { Text = "OK", Left = 150, Width = 100, Top = 70, DialogResult = DialogResult.OK };

            confirmation.Click += (sender, e) => { promptForm.Close(); };

            promptForm.Controls.Add(textBox);
            promptForm.Controls.Add(confirmation);
            promptForm.Controls.Add(textLabel);

            return promptForm.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }

        public void PlayComputerTurn()
        {
            if (gameStarted)
            {
                int computerMove = GetComputerMove();
                if (computerMove >= 0 && computerMove < 9 && gameBoard[computerMove] == null)
                {
                    gameBoard[computerMove] = computerSymbol;
                    Color buttonColor = determineColor(computerSymbol);
                    SetButtonContent(computerMove, computerSymbol);
                    SetButtonColor(computerMove, buttonColor);

                    checkForWinner();
                    currentTurn++;
                    if (isAgainstComputer && currentTurn % 2 == 1)
                    {
                        PlayComputerTurn();
                    }
                }
                else
                {
                    PlayComputerTurn();
                }
            }
        }

        private void SetButtonContent(int buttonIndex, string symbol)
        {
            Button button = GetButtonByIndex(buttonIndex);
            if (button != null)
            {
                button.Text = symbol;
            }
        }

        private Button GetButtonByIndex(int buttonIndex)
        {
            int row = buttonIndex / boardSize;
            int col = buttonIndex % boardSize;

            if (row >= 0 && row < boardSize && col >= 0 && col < boardSize)
            {
                return buttons[row, col];
            }
            else
            {
                return null;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            isAgainstComputer = true;

            difficultyLevel = DifficultyLevel.Medium;

            if (!gameStarted)
            {
                reset();
                gameStarted = true;
                if (currentTurn % 2 == 1)
                {
                    PlayComputerTurn();
                }
            }
            else if (currentTurn % 2 == 1)
            {
                PlayComputerTurn();
            }
        }

        public enum DifficultyLevel
        {
            Easy,
            Medium,
            Hard
        }

        public int GetComputerMove()
        {
            if (isAgainstComputer)
            {
                Random random = new Random();
                if (difficultyLevel == DifficultyLevel.Easy)
                {
                    return random.Next(0, 9);
                }
                else if (difficultyLevel == DifficultyLevel.Medium)
                {
                    int blockingMove = GetBlockingMove();
                    if (blockingMove != -1)
                    {
                        return blockingMove;
                    }
                    else
                    {
                        return random.Next(0, 9);
                    }
                }
                // Poziom trudny: zastosuj bardziej zaawansowaną logikę (można rozbudować)
                else if (difficultyLevel == DifficultyLevel.Hard)
                {
                    // Dodaj bardziej zaawansowaną logikę
                    // ...
                }
            }
            return -1;
        }


        private int GetBlockingMove()
        {
            for (int i = 0; i < 8; i++)
            {
                String combination = "";
                int one = 0, two = 0, three = 0;

                switch (i)
                {
                    case 0:
                        if (gameBoard.Length > 8)
                        {
                            combination = gameBoard[0] + gameBoard[4] + gameBoard[8];
                            one = 0;
                            two = 4;
                            three = 8;
                        }
                        break;
                    case 1:
                        if (gameBoard.Length > 6)
                        {
                            combination = gameBoard[2] + gameBoard[4] + gameBoard[6];
                            one = 2;
                            two = 4;
                            three = 6;
                        }
                        break;
                    case 2:
                        if (gameBoard.Length > 2)
                        {
                            combination = gameBoard[0] + gameBoard[1] + gameBoard[2];
                            one = 0;
                            two = 1;
                            three = 2;
                        }
                        break;
                    case 3:
                        if (gameBoard.Length > 5)
                        {
                            combination = gameBoard[3] + gameBoard[4] + gameBoard[5];
                            one = 3;
                            two = 4;
                            three = 5;
                        }
                        break;
                    case 4:
                        if (gameBoard.Length > 8)
                        {
                            combination = gameBoard[6] + gameBoard[7] + gameBoard[8];
                            one = 6;
                            two = 7;
                            three = 8;
                        }
                        break;
                    case 5:
                        if (gameBoard.Length > 6)
                        {
                            combination = gameBoard[0] + gameBoard[3] + gameBoard[6];
                            one = 0;
                            two = 3;
                            three = 6;
                        }
                        break;
                    case 6:
                        if (gameBoard.Length > 7)
                        {
                            combination = gameBoard[1] + gameBoard[4] + gameBoard[7];
                            one = 1;
                            two = 4;
                            three = 7;
                        }
                        break;
                    case 7:
                        if (gameBoard.Length > 8)
                        {
                            combination = gameBoard[2] + gameBoard[5] + gameBoard[8];
                            one = 2;
                            two = 5;
                            three = 8;
                        }
                        break;
                }

                if (one >= 0 && one < gameBoard.Length && two >= 0 && two < gameBoard.Length && three >= 0 && three < gameBoard.Length)
                {
                    if (gameBoard[one] != null && gameBoard[two] != null && gameBoard[three] != null)
                    {
                        if (combination.Equals("XXX"))
                        {
                            if (gameBoard[one] == null) return one;
                            else if (gameBoard[two] == null) return two;
                            else if (gameBoard[three] == null) return three;
                        }
                    }
                }

            }
            return -1;
        }

        public void ShowGameStats()
        {
            Console.WriteLine("ShowGameStats() called");

            MessageBox.Show($"Statystyki gry:\nGracz X ( {player1Symbol} ) : {player1Wins} zwycięstwo\nGracz O ( {player2Symbol} ) : {player2Wins} zwycięstwo\nRemisy: {draws}",
            "Statystyki gry", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Task.Delay(500).Wait();
            reset();
        }


        private void button14_Click(object sender, EventArgs e)
        {
            difficultyLevel = DifficultyLevel.Easy;
            MessageBox.Show("Wybrano łatwy poziom trudności.", "Poziom trudności", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            difficultyLevel = DifficultyLevel.Medium;
            MessageBox.Show("Wybrano średni poziom trudności.", "Poziom trudności", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            difficultyLevel = DifficultyLevel.Hard;
            MessageBox.Show("Wybrano trudny poziom trudności.", "Poziom trudności", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void InitializeBoard()
        {
            buttons = new Button[boardSize, boardSize];
            int buttonSize = 50;
            int startX = 300;
            int startY = 100;

            for (int row = 0; row < boardSize; row++)
            {
                for (int col = 0; col < boardSize; col++)
                {
                    Button button = new Button();
                    button.Width = button.Height = buttonSize;
                    button.Left = startX + col * buttonSize;
                    button.Top = startY + row * buttonSize;
                    button.Font = new Font("Arial", 16);
                    button.Click += BoardButtonClick;
                    button.Padding = new Padding(0);

                    Controls.Add(button);
                    buttons[row, col] = button;
                }
            }
        }

        private void BoardButtonClick(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            if (currentGameState == GameState.NotStarted)
            {
                for (int row = 0; row < boardSize; row++)
                {
                    for (int col = 0; col < boardSize; col++)
                    {
                        if (buttons[row, col] == clickedButton)
                        {
                            int index = row * boardSize + col;
                            if (index >= 0 && index < gameBoard.Length && gameBoard[index] == null)
                            {
                                currentTurn++;
                                gameBoard[index] = returnSymbol(currentTurn);
                                Color buttonColor = determineColor(gameBoard[index]);
                                clickedButton.BackColor = buttonColor;
                                clickedButton.Text = gameBoard[index];
                                checkForWinner();
                                moveHistory.Push(index);
                                if (currentGameState == GameState.NotStarted && isAgainstComputer && currentTurn % 2 == 1)
                                {
                                    PlayComputerTurn();
                                }
                            }
                            break; // Przerwij pętlę po znalezieniu przycisku
                        }
                    }
                }
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            int newSize = GetBoardSizeFromUser();

            if (newSize >= 4 && newSize <= 10)
            {
                boardSize = newSize;
                InitializeBoard();
                reset();
            }
            else
            {
                MessageBox.Show("Wprowadź nie standardowy rozmiar planszy od 4x4 do 10x10.", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int GetBoardSizeFromUser()
        {
            Form promptForm = new Form();
            promptForm.Width = 300;
            promptForm.Height = 150;
            promptForm.Text = "Ustaw Rozmiar Planszy";

            Label textLabel = new Label() { Left = 50, Top = 20, Text = "Podaj rozmiar planszy wpisując od 4 do 10:" };
            TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 200 };
            Button confirmation = new Button() { Text = "OK", Left = 150, Width = 100, Top = 70, DialogResult = DialogResult.OK };

            confirmation.Click += (sender, e) => { promptForm.Close(); };

            promptForm.Controls.Add(textBox);
            promptForm.Controls.Add(confirmation);
            promptForm.Controls.Add(textLabel);

            return promptForm.ShowDialog() == DialogResult.OK ? int.Parse(textBox.Text) : 0;
        }

        private void SetVisualEffects(GameState gameState)
        {
            switch (gameState)
            {
                case GameState.Player1Won:
                    MessageBox.Show("Gracz X WYGRAŁ!", "Mamy zwycięzcę!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    break;
                case GameState.Player2Won:
                    MessageBox.Show("Gracz O WYGRAŁ!", "Mamy zwycięzcę!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    break;
                case GameState.Draw:
                    MessageBox.Show("REMIS!", "Dziś nie ma zwycięzcy", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    break;
            }

            // Możesz dodać dodatkowe efekty wizualne tutaj, na przykład migotanie przycisków, animacje, itp.
        }

        private void button10_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void button18_Click_1(object sender, EventArgs e)
        {
            UndoMove();
        }

        private void SaveGameState()
        {
            Console.WriteLine("Zapisano stan gry i historię ruchów.");
        }

        private void UndoMove()
        {
            if (moveHistory.Count > 0)
            {
                int lastMove = moveHistory.Pop();
                gameBoard[lastMove] = null;
                SetButtonColor(lastMove, Color.White);
                SetButtonContent(lastMove, "");
                currentTurn--;
                if (isAgainstComputer && currentTurn % 2 == 1)
                {
                    UndoMove();
                }
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            SaveGameState();
        }
    }

    public enum GameState
    {
        NotStarted,
        Player1Won,
        Player2Won,
        Draw
    }
}